<?php
$servername = "localhost";
$username = "root";
$password = "Juanrojas.";
$dbNAME = "recibosa";
$conexion=new mysqli ($servername, $username, $password, $dbNAME);
$conexion ->set_charset("utf8");

?>